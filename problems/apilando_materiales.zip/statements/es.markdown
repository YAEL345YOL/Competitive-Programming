# Descripción

La estación esta muy desordenada, como asistente de logística el jefe te ha asignado ordenar $n_i$ cajas en pirámides de diferentes tamaños, las pirámides que puedes formar son las siguientes:

![Pirámides de contenedores](https://github.com/user-attachments/assets/82afe9a5-2dc4-4912-8f83-1708e622e7dc)

El jefe te pidió **maximizar** el numero de pirámides que puedes formar, la condición que te dio el jefe es que **no puedes formar más de una pirámide del mismo tamaño**.  Además, en caso de que te sobren cajas y no puedas formar mas pirámides debes desechar dichas cajas.
# Entrada

Un entero $t$ seguido de $t$ casos de prueba, para cada caso de prueba un numero $n_i$ indicando el numero de cajas disponibles del $i$-esimo caso.

# Salida

Para cada caso de prueba $n_i$ indica el numero máximo de pirámides que puedes formar con la condición dada.

# Ejemplo

||input
5
1
5
10
20
32
||output
1
2
3
4
4
||description
En el primer caso, si tienes 1 contender puedes formar un triangulo de 1.

En el segundo caso, si tienes 5 contenedores puedes formar un triangulo de 1 y 3, te sobra 1 contenedor.

En el tercer caso con 10 contenedores puedes formar un triangulo de 1, 3 y 6.

En el cuarto caso con 20 puedes formar un triangulo de 1, 3, 6 y 10.
||input
3
1032
31234
1204835
||output
17
56
192
||description
N/A
||end

# Límites

* $1 \leq n_i \leq 10^{11}$
* $1 \leq t \leq 10^6$
