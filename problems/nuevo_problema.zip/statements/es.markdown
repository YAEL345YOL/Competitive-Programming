# Descripción

Boronita y Canelita están jugando una version modificada del juego Stop en el patio de su casa, su patio esta representado como un plano cartesiano de dos dimensiones. El juego consiste en lo siguiente: ambos empiezan desde el origen $(0,0)$ y pueden moverse de manera independiente conforme sus desplazamientos disponibles, al finalizar ambos **todos** sus desplazamientos, Canelita deberá calcular la mínima distancia de donde esta actualmente a Boronita.

La mínima distancia entre dos puntos $A$ y $B$ se calcula con la formula:

$$d=\sqrt{(B_x-A_x)^2+(B_y-A_y)^2}$$

# Entrada

Se te darán dos enteros $n$ y $k$ indicando la cantidad de desplazamientos de Boronita y Canelita, seguido de $n$ pares $(b_x,b_y)$ indicando el $i$-ésimo desplazamiento de Boronita, seguido de $k$ pares$(c_x,c_y)$ indicando el $j$-ésimo desplazamiento de Canelita.

# Salida

Ayuda a Canelita a ganarle a boronita en stop indicando la mínima distancia de donde esta a Boronita con las condiciones dadas.

# Ejemplo

||input
1

||output
Case #1: 3
||description
Explicación
||input
5
10
||output
Case #2: 15
||description
hola
||end

# Límites

* Aquí
* Van
* Los
* Límites
